package br.triadworks.javaweb.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.triadworks.javaweb.modelo.Caloteiro;

public class CaloteiroDAO {

	private Connection conexao;

	public CaloteiroDAO(Connection connection) {
		this.conexao = connection;

	}

	public void adicionar(Caloteiro caloteiro) {
		try {

			StringBuilder sql = new StringBuilder();
			sql.append("Insert into caloteiro (nome,email,devendo,dataDivida) values (?,?,?,?)");

			PreparedStatement pstm = conexao.prepareStatement(sql.toString());
			pstm.setString(1, caloteiro.getNome());
			pstm.setString(2, caloteiro.getEmail());
			pstm.setInt(3, caloteiro.getDevendo());
			pstm.setDate(4, new Date(caloteiro.getDataDivida()
					.getTimeInMillis()));

			pstm.execute();
			pstm.close();
			conexao.close();

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

	public List<Caloteiro> getListar() {

		try {

			List<Caloteiro> caloteiros = new ArrayList<Caloteiro>();
			Caloteiro caloteiro = null;
			StringBuilder sql = new StringBuilder();
			sql.append("select id,nome,email,devendo,dataDivida from caloteiro");
			PreparedStatement stmt = this.conexao.prepareStatement(sql
					.toString());

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {

				Calendar dataDivida = Calendar.getInstance();
				dataDivida.setTime(rs.getDate("dataDivida"));

				caloteiro = new Caloteiro();
				caloteiro.setId(rs.getLong("id"));
				caloteiro.setNome(rs.getString("nome"));
				caloteiro.setEmail(rs.getString("email"));
				caloteiro.setDevendo(new Integer(rs.getInt("devendo")));
				caloteiro.setDataDivida(dataDivida);
				caloteiros.add(caloteiro);

			}
			rs.close();
			stmt.close();
			return caloteiros;

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

	}

	public void excluir(Caloteiro caloteiro) throws SQLException {
		PreparedStatement stmt = null;
		try {

			StringBuilder sql = new StringBuilder();
			sql.append(" DELETE FROM caloteiro ");
			sql.append(" WHERE  id = ?");
			stmt = conexao.prepareStatement(sql.toString());
			stmt.setLong(1, caloteiro.getId());
			stmt.execute();
			stmt.close();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	public void alterar(Caloteiro caloteiro) throws SQLException {
		PreparedStatement stmt = null;
		try {

			StringBuffer sql = new StringBuffer();
			sql.append("UPDATE caloteiro ");
			sql.append("SET    nome=? , ");
			sql.append("       email=?, ");
			sql.append("       devendo=?, ");
			sql.append(" datadivida=?, ");
			sql.append(" id = ? ");
			stmt = conexao.prepareStatement(sql.toString());
			stmt.setString(1, caloteiro.getNome());
			stmt.setString(2, caloteiro.getEmail());
			stmt.setInt(3, caloteiro.getDevendo());
			stmt.setDate(4, new Date(caloteiro.getDataDivida()
					.getTimeInMillis()));
			stmt.setLong(5, caloteiro.getId());
			stmt.execute();
			stmt.close();

		} catch (SQLException e) {

			throw new RuntimeException(e.getMessage());

		}

	}

}
