package br.triadworks.javaweb.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import br.triadworks.javaweb.util.Constantes;

public class ConnectionFactory {

	public Connection getConnection(){
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			return DriverManager.getConnection(Constantes.URL_CONEXAO_MYSQL,
					Constantes.USER_BD, Constantes.PASSWORD_BD);
		}catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
	}

}
