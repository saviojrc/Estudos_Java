package br.triadworks.javaweb.logica;

import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.triadworks.javaweb.dao.CaloteiroDAO;
import br.triadworks.javaweb.modelo.Caloteiro;
import br.triadworks.javaweb.modelo.Logica;
import br.triadworks.javaweb.util.Formatacao;

public class AdicionarCaloteiroLogica implements Logica {

	public void executa(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String devendo = request.getParameter("devendo");
		String dataDivida = request.getParameter("dataDivida");
		Caloteiro caloteiro = new Caloteiro();
		Connection connection = (Connection) request.getAttribute("conexao");
		CaloteiroDAO dao = new CaloteiroDAO(connection);
		caloteiro.setNome(nome);
		caloteiro.setEmail(email);
		caloteiro.setDevendo(Formatacao.stringToInteger(devendo));
		caloteiro.setDataDivida(Formatacao.stringToCalendar(dataDivida));

		dao.adicionar(caloteiro);

		RequestDispatcher rs = request
				.getRequestDispatcher("sistema?logica=ListarCaloteiro");
		rs.forward(request, response);

	}
}
