package br.triadworks.javaweb.logica;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.triadworks.javaweb.dao.CaloteiroDAO;
import br.triadworks.javaweb.modelo.Caloteiro;
import br.triadworks.javaweb.modelo.Logica;

public class ExcluirCaloteiroLogica implements Logica {

	public void executa(HttpServletRequest request, HttpServletResponse response) {
		Caloteiro caloteiro = new Caloteiro();
		Connection connection = (Connection) request.getAttribute("conexao");
		CaloteiroDAO dao = new CaloteiroDAO(connection);
		try {
			String id = request.getParameter("id");
			caloteiro.setId(Long.valueOf(id));
			dao.excluir(caloteiro);
			RequestDispatcher rs = request
					.getRequestDispatcher("sistema?logica=ListarCaloteiro");
			rs.forward(request, response);

		} catch (SQLException e) {
			e.getMessage();
			e.printStackTrace();
		} catch (ServletException e) {
			e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			e.getMessage();
			e.printStackTrace();
		}

	}
}
