package br.triadworks.javaweb.logica;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.triadworks.javaweb.dao.CaloteiroDAO;
import br.triadworks.javaweb.modelo.Caloteiro;
import br.triadworks.javaweb.modelo.Logica;

public class ListarCaloteiroLogica implements Logica {

	public void executa(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Connection connection = (Connection) request.getAttribute("conexao");
		CaloteiroDAO dao = new CaloteiroDAO(connection);
		List<Caloteiro> lista = dao.getListar();

		RequestDispatcher rs = request
				.getRequestDispatcher("jsp/lista-caloteiro.jsp");

		request.setAttribute("lista", lista);
		rs.forward(request, response);

	}

}
