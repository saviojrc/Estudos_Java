/**
 * 
 */
package br.triadworks.javaweb.modelo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author jweb26
 *
 */
public interface Logica {

	void executa(HttpServletRequest request, HttpServletResponse response)
			throws Exception;
}
