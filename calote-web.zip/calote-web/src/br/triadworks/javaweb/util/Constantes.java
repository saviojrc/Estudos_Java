package br.triadworks.javaweb.util;

public class Constantes {

	public static final String URL_CONEXAO_MYSQL = "jdbc:mysql://localhost/3WJavaWeb26";
	public static final String USER_BD = "root";
	public static final String PASSWORD_BD = "root";

	public static final String FORMATO_DATA_BR = "dd/MM/yyyy";
}
