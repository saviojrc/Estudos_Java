package br.triadworks.javaweb.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Formatacao {

	public static Integer stringToInteger(String string) {
		return new Integer(string);

	}

	public static Calendar stringToCalendar(String stringData) {
		Calendar dataConvertida = null;
		try {
			Date data = new SimpleDateFormat(Constantes.FORMATO_DATA_BR)
					.parse(stringData);
			dataConvertida = Calendar.getInstance();
			dataConvertida.setTime(data);
			return dataConvertida;

		} catch (ParseException e) {
			throw new IllegalArgumentException("Erro de conversao de data");
		}
	}
}
