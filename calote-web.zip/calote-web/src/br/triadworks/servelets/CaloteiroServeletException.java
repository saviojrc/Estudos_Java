package br.triadworks.servelets;

import javax.servlet.ServletException;

public class CaloteiroServeletException extends ServletException {
	public CaloteiroServeletException(String msg) {
		super(msg);
	}

	public CaloteiroServeletException() {
		super();
	}
}
