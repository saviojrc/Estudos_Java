package br.triadworks.servelets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/OlaMundo")
public class MinhaPrimeiraServelet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter sysout = response.getWriter();
		sysout.println("<html>");
		sysout.println("<head> ");
		sysout.println("<title> ");
		sysout.println("Minha primeira página ");
		sysout.println("</title> ");
		sysout.println("</head> ");
		sysout.println("<body> ");
		sysout.println("Ebaa,meu primeiro servelet: D! ");
		sysout.println("</body> ");
		sysout.println("</html> ");

	}

}
